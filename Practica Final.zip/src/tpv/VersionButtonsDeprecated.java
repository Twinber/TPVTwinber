package tpv;
//TODO Boton Cobrar
//TODO Boton OK de Nuevo Articulo
//TODO Teclado tactil
//TODO MENUS ADMINISTRADOR
//TODO MENU GERENTE
//TODO LOGIN USUARIO
//TODO INTERFAZ SEGUN USUARIO
//TODO SALDO CAJA
//TODO CARGA TICKET NO PAGADOS AL ARRANCAR

import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dialog;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Insets;
import java.awt.Label;
import java.awt.Panel;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;

public class VersionButtonsDeprecated extends Frame implements ActionListener{

	private static final long serialVersionUID = 1L;
	// ******** COMPONENTES DE VENTANA PRINCIPAL ********
	Panel panelizquierdo = new Panel();
	Panel ticketActivo = new Panel();
	Panel ticketActivoSuperior = new Panel();
	Button botonUsuario = new Button("Usuario");
	Label numeroTicket = new Label("Ticket n� 000000");
	Panel ticketActivoCentral = new Panel();
	List<Label> detalleTicket = new ArrayList<Label>();
	Panel ticketActivoInferior = new Panel();
	Button botonNuevoTicket = new Button("Nuevo Ticket");
	Label sumaTicket = new Label("Total... 0,00");
	Panel menus = new Panel();
	Button botonArriba = new Button("Subir");
	Button botonAbajo = new Button("Bajar");
	Button botonBorrar = new Button ("Borrar");
	Button botonCobrar = new Button ("Cobrar");
	Button botonCaja = new Button ("Caja");
	Panel panelderecho = new Panel();
	Panel categorias = new Panel();
	Button botonBebidas = new Button("BEBIDAS");
	Button botonEnsaldas = new Button("ENSALADAS");
	Button botonEntrantes = new Button("ENTRANTES");
	Button botonVinos = new Button("VINOS");
	Button botonCarnes = new Button("CARNES");
	Button botonPescados = new Button("PESCADOS");
	Button botonPostres = new Button("POSTRES");
	Button botonHelados = new Button("HELADOS");
	Button botonCafes = new Button("CAFES");
	Button botonMenu = new Button("MENU");
	Panel articulos = new Panel();
	Button botonNuevoArticulo = new Button("Nuevo...");
	Panel ticketsAbiertos = new Panel();
	
	// ******** COMPONENTES DE DIALOGO ALTA DE ARTICULOS ********
	Dialog altas = new Dialog(this,"Art�culo no registrado",true);
	Label descripcionLabel = new Label("descripci�n");
	TextField descripcionArticulo = new TextField("",40);
	Label cantidadLabel = new Label("cantidad");
	TextField cantidadArticulo = new TextField("",40);
	Label precioLabel = new Label("precio");
	TextField precioArticulo = new TextField("",40);
	Button n7altas = new Button("7");
	Button n8altas = new Button("8");
	Button n9altas = new Button("9");
	Button n4altas = new Button("4");
	Button n5altas = new Button("5");
	Button n6altas = new Button("6");
	Button n1altas = new Button("1");
	Button n2altas = new Button("2");
	Button n3altas = new Button("3");
	Button n0altas = new Button("0");
	Button comaaltas = new Button(",");
	Button delaltas = new Button("del");
	Button okaltas = new Button("OK");
	Button escaltas = new Button("ESC");
	Button nuevoaltas = new Button ("nuevo art�culo");

	// ******** COMPONENTES DE DIALOGO COBRAR ********
	Dialog cobrar = new Dialog(this,"�Cuanto nos da el cliente?",true);
	TextField importeEntregado = new TextField("0",40);
	Button n7cobrar = new Button("7");
	Button n8cobrar = new Button("8");
	Button n9cobrar = new Button("9");
	Button n4cobrar = new Button("4");
	Button n5cobrar = new Button("5");
	Button n6cobrar = new Button("6");
	Button n1cobrar = new Button("1");
	Button n2cobrar = new Button("2");
	Button n3cobrar = new Button("3");
	Button n0cobrar = new Button("0");
	Button comacobrar = new Button(",");
	Button delcobrar = new Button("del");
	Button okcobrar = new Button("OK");
	Button esccobrar = new Button("ESC");	

	// ******** COMPONENTES DE DIALOGO NUEVO TICKET ********
	Dialog nuevoTicket = new Dialog(this,"Crear Ticket Nuevo",true);
	Button mesa1 = new Button("Mesa 1");
	Button mesa2 = new Button("Mesa 2");
	Button mesa3 = new Button("Mesa 3");
	Button mesa4 = new Button("Mesa 4");
	Button mesa5 = new Button("Mesa 5");
	Button mesa6 = new Button("Mesa 6");
	Button mesa7 = new Button("Mesa 7");
	Button mesa8 = new Button("Mesa 8");
	Button mesa9 = new Button("Mesa 9");
	Button mesa10 = new Button("Mesa 10");
	Button barra = new Button("Barra");
	Button llevar = new Button("Llevar");
	
	// ******** VARIABLES GENERALES y JBC ********
	List<Button> listaActiva = new ArrayList<Button>(); // Almacena lista de productos de categoria activa
	List<Ticket> listaTicketsAbiertos = new ArrayList<Ticket>(); //Almacena lista de tickets sin cobrar
	Ticket activo;
	String categoriaActiva;
	static Connection conexion=null;
	static String dsn = new String("jdbc:mysql://localhost/restaurante");
	ResultSet rs=null;
	Statement stmt=null;
	int contBarra;
	int contLlevar;
	int indiceDetalleActivo = -1;
	String cantidad="";
	String precio="";
	String importe="";

	// Tama�os predefinidos
	Dimension botonnumero = new Dimension(75,75);
	Dimension botongrande = new Dimension(130,60);
	Dimension botonmediano = new Dimension(107,60);
	Dimension botonpeque�o = new Dimension(100,50);
	//Colores
	Color Azul = new Color(161, 214, 249);
	Color Verde = new Color(134,248,169);
	Color Rojo = new Color (255,106,95);
	Color Amarillo = new Color (246,189,69);
	Color Morado = new Color (241,193,255);
	Color Papel = new Color (255,255,204);

	public VersionButtonsDeprecated() {

		//******** VENTANA PRINCIPAL ********

		//******** PANEL IZQUIERDO ********
		// Panel ticketActivoSuperior
		ticketActivoSuperior.setPreferredSize(new Dimension(300, 55));
		botonUsuario.setPreferredSize(botonpeque�o);
		botonUsuario.setBackground(Morado);
		botonUsuario.setFocusable(false);
		ticketActivoSuperior.add(botonUsuario);
		numeroTicket.setPreferredSize(botonpeque�o);
		numeroTicket.setFocusable(false);
		ticketActivoSuperior.add(numeroTicket);

		//Panel ticketActivoCentral
		ticketActivoCentral.setLayout(new FlowLayout(FlowLayout.RIGHT,1,1));
		ticketActivoCentral.setPreferredSize(new Dimension(300, 500));
		ticketActivoCentral.setBackground(Color.WHITE);

		//Panel ticketActivoInferior
		ticketActivoInferior.setPreferredSize(new Dimension(300, 55));
		ticketActivoInferior.setLayout(new FlowLayout(FlowLayout.RIGHT));
		botonNuevoTicket.setPreferredSize(botonpeque�o);
		botonNuevoTicket.setBackground(Morado);
		botonNuevoTicket.setFocusable(false);
		ticketActivoInferior.add(botonNuevoTicket);
		ticketActivoInferior.add(sumaTicket);

		// Panel ticketActivo
		ticketActivo.setPreferredSize(new Dimension(300, 610));
		ticketActivo.setLayout(new BorderLayout());
		ticketActivo.add("North",ticketActivoSuperior);
		ticketActivo.add("Center", ticketActivoCentral);
		ticketActivo.add("South",ticketActivoInferior);


		//Panel Menus
		menus.setPreferredSize(new Dimension(300,60));
		menus.setLayout(new GridLayout (1,5,3,3));
		menus.add(botonArriba);
		botonArriba.setBackground(Azul);
		botonArriba.setFocusable(false);
		menus.add(botonAbajo);
		botonAbajo.setBackground(Azul);
		botonAbajo.setFocusable(false);
		menus.add(botonBorrar);
		botonBorrar.setBackground(Rojo);
		botonBorrar.setFocusable(false);
		menus.add(botonCobrar);
		botonCobrar.setBackground(Amarillo);
		botonCobrar.setFocusable(false);
		menus.add(botonCaja);
		botonCaja.setBackground(Verde);
		botonCaja.setFocusable(false);

		//Ensamble de panelizquierdo
		panelizquierdo.setPreferredSize(new Dimension(310, 680));
		panelizquierdo.add(ticketActivo);
		panelizquierdo.add(menus);
		panelizquierdo.setBackground(Papel);

		// ******** PANEL DERECHO ********
		// Panel categorias
		categorias.setLayout(new FlowLayout(FlowLayout.LEFT));
		categorias.setPreferredSize(new Dimension(675, 130));
		botonBebidas.setPreferredSize(botongrande);
		botonBebidas.setBackground(Verde);
		botonEnsaldas.setPreferredSize(botongrande);
		botonEnsaldas.setBackground(Verde);
		botonEntrantes.setPreferredSize(botongrande);
		botonEntrantes.setBackground(Verde);
		botonVinos.setPreferredSize(botongrande);
		botonVinos.setBackground(Verde);
		botonCarnes.setPreferredSize(botongrande);
		botonCarnes.setBackground(Verde);
		botonPescados.setPreferredSize(botongrande);
		botonPescados.setBackground(Verde);
		botonPostres.setPreferredSize(botongrande);
		botonPostres.setBackground(Verde);
		botonHelados.setPreferredSize(botongrande);
		botonHelados.setBackground(Verde);
		botonCafes.setPreferredSize(botongrande);
		botonCafes.setBackground(Verde);
		botonMenu.setPreferredSize(botongrande);
		botonMenu.setBackground(Verde);
		categorias.add(botonBebidas);
		categorias.add(botonEnsaldas);
		categorias.add(botonEntrantes);
		categorias.add(botonVinos);
		categorias.add(botonCarnes);
		categorias.add(botonPescados);
		categorias.add(botonPostres);
		categorias.add(botonHelados);
		categorias.add(botonCafes);
		categorias.add(botonMenu);

		//Panel articulos
		articulos.setLayout(new FlowLayout(FlowLayout.LEFT));
		articulos.setPreferredSize(new Dimension(675,330));
		botonNuevoArticulo.setPreferredSize(botonmediano);		
		botonNuevoArticulo.setBackground(Amarillo);
		botonNuevoArticulo.setFocusable(false);
		articulos.add(botonNuevoArticulo);	
		
		// Panel ticketsAbiertos
		ticketsAbiertos.setLayout(new FlowLayout(FlowLayout.LEFT));
		ticketsAbiertos.setPreferredSize(new Dimension (675,220));
				
		//Ensamble de panelderecho
		panelderecho.setLayout(new FlowLayout(FlowLayout.LEFT ));
		panelderecho.setPreferredSize(new Dimension(685, 680));
		panelderecho.add(categorias);
		panelderecho.add(articulos);
		panelderecho.add(ticketsAbiertos);
		panelderecho.setBackground(Papel);

		//A�adimos Listeners a VentanaPrincipal
		addWindowListener( new WindowAdapter (){
			public void windowClosing(WindowEvent we){
				try
				{
					conexion.close();
					if (stmt!=null) stmt.close();
					if (rs!=null) rs.close();
				}
				catch(SQLException e)
				{
					System.out.println("error al cerrar "+e.toString());
				}
				System.exit(0);
			}
		});
		botonNuevoArticulo.addActionListener(this);
		botonBebidas.addActionListener(this);
		botonEnsaldas.addActionListener(this);
		botonEntrantes.addActionListener(this);
		botonVinos.addActionListener(this);
		botonCarnes.addActionListener(this);
		botonPescados.addActionListener(this);
		botonPostres.addActionListener(this);
		botonHelados.addActionListener(this);
		botonCafes.addActionListener(this);
		botonMenu.addActionListener(this);
		botonUsuario.addActionListener(this);
		botonNuevoTicket.addActionListener(this);
		botonArriba.addActionListener(this);
		botonAbajo.addActionListener(this);
		botonBorrar.addActionListener(this);
		botonCobrar.addActionListener(this);
		botonCaja.addActionListener(this);

		//Ensamble de VentanaPrincipal
		setLayout(new FlowLayout(FlowLayout.LEFT ));
		add (panelizquierdo);
		add (panelderecho);
		setTitle ("Twinber TPV");
		setSize (1015,720);
		setVisible(true);
		setResizable(false);

		// ******** CARGA DE ESTADO INICIAL ********
		categoriaActiva = "BEBIDAS";
		rellenaListaActiva(categoriaActiva);
		//TODO COMPROBAR SI HAY TICKETS SIN PAGAR Y CARGARLOS (CASO : "SE VA LA LUZ")

		//********  DIALOGO NUEVO ARTICULO ********
		//Ensamble de Dialogo Nuevo Articulo
		altas.setLayout(new GridBagLayout());
		altas.setSize(360,640);
		GridBagConstraints gbcAltas = new GridBagConstraints();
		gbcAltas.fill = GridBagConstraints.BOTH;
		Insets separaciones = new Insets(2,2,2,2);
		gbcAltas.insets = separaciones;
		gbcAltas.gridx = 0;
		gbcAltas.gridy = 0;
		gbcAltas.gridwidth = 4;
		gbcAltas.gridheight = 1;
		altas.add(descripcionLabel, gbcAltas);
		gbcAltas.gridy = 1;
		altas.add(descripcionArticulo,gbcAltas);
		gbcAltas.gridy = 2;
		altas.add(cantidadLabel, gbcAltas);
		gbcAltas.gridy = 3;
		altas.add(cantidadArticulo,gbcAltas);
		gbcAltas.gridy = 4;
		altas.add(precioLabel,gbcAltas);
		gbcAltas.gridy = 5;
		altas.add(precioArticulo,gbcAltas);
		gbcAltas.gridy = 6;
		gbcAltas.gridwidth = 1;
		altas.add(n7altas,gbcAltas);
		gbcAltas.gridx = 1;
		altas.add(n8altas,gbcAltas);
		gbcAltas.gridx = 2;
		altas.add(n9altas,gbcAltas);
		gbcAltas.gridx = 3;
		gbcAltas.gridheight = 2;
		altas.add(okaltas,gbcAltas);
		gbcAltas.gridx = 0;
		gbcAltas.gridy = 7;
		gbcAltas.gridheight = 1;
		altas.add(n4altas , gbcAltas);
		gbcAltas.gridx = 1;
		altas.add(n5altas,gbcAltas);
		gbcAltas.gridx = 2;
		altas.add(n6altas,gbcAltas);
		gbcAltas.gridx = 0;
		gbcAltas.gridy = 8;
		altas.add(n1altas,gbcAltas);
		gbcAltas.gridx = 1;
		altas.add(n2altas,gbcAltas);
		gbcAltas.gridx = 2;
		altas.add(n3altas,gbcAltas);
		gbcAltas.gridx = 3;
		gbcAltas.gridheight = 2;
		altas.add(escaltas,gbcAltas);
		gbcAltas.gridheight = 1;
		gbcAltas.gridx = 0;
		gbcAltas.gridy = 9;
		altas.add(n0altas,gbcAltas);
		gbcAltas.gridx = 1;
		altas.add(comaaltas,gbcAltas);
		gbcAltas.gridx = 2;
		altas.add(delaltas,gbcAltas);
		gbcAltas.gridx = 0;
		gbcAltas.gridwidth = 4;
		gbcAltas.gridy = 10;
		altas.add(nuevoaltas,gbcAltas);
		//Listener del Dialogo Alta Articulo
		altas.addWindowListener( new WindowAdapter(){
			public void windowClosing(WindowEvent we){
				altas.setVisible(false);
				cantidad="";
				cantidadArticulo.setText(cantidad);
				precio="";
				precioArticulo.setText(precio);
			}
		});
		n0altas.addActionListener(this);
		n1altas.addActionListener(this);
		n2altas.addActionListener(this);
		n3altas.addActionListener(this);
		n4altas.addActionListener(this);
		n5altas.addActionListener(this);
		n6altas.addActionListener(this);
		n7altas.addActionListener(this);
		n8altas.addActionListener(this);
		n9altas.addActionListener(this);
		comaaltas.addActionListener(this);
		delaltas.addActionListener(this);
		escaltas.addActionListener(this);
		okaltas.addActionListener(this);
		nuevoaltas.addActionListener(this);

		// Coloreamos botones

		n0altas.setBackground(Azul);
		n1altas.setBackground(Azul);
		n2altas.setBackground(Azul);
		n3altas.setBackground(Azul);
		n4altas.setBackground(Azul);
		n5altas.setBackground(Azul);
		n6altas.setBackground(Azul);
		n7altas.setBackground(Azul);
		n8altas.setBackground(Azul);
		n9altas.setBackground(Azul);
		comaaltas.setBackground(Azul);
		delaltas.setBackground(Azul);
		okaltas.setBackground(Verde);
		escaltas.setBackground(Rojo);
		nuevoaltas.setBackground(Amarillo);

		//Damos dimensiones a los Componentes

		n0altas.setPreferredSize(botonnumero);
		n1altas.setPreferredSize(botonnumero);
		n2altas.setPreferredSize(botonnumero);
		n3altas.setPreferredSize(botonnumero);
		n4altas.setPreferredSize(botonnumero);
		n5altas.setPreferredSize(botonnumero);
		n6altas.setPreferredSize(botonnumero);
		n7altas.setPreferredSize(botonnumero);
		n8altas.setPreferredSize(botonnumero);
		n9altas.setPreferredSize(botonnumero);
		nuevoaltas.setPreferredSize(new Dimension ( 320,75));

		// Evitamos que los botones cojan el Foco
		n0altas.setFocusable(false);
		n1altas.setFocusable(false);
		n2altas.setFocusable(false);
		n3altas.setFocusable(false);
		n4altas.setFocusable(false);
		n5altas.setFocusable(false);
		n6altas.setFocusable(false);
		n7altas.setFocusable(false);
		n8altas.setFocusable(false);
		n9altas.setFocusable(false);
		comaaltas.setFocusable(false);
		delaltas.setFocusable(false);
		okaltas.setFocusable(false);
		escaltas.setFocusable(false);
		nuevoaltas.setFocusable(false);

		cantidadArticulo.setEditable(false);
		precioArticulo.setEditable(false);
		
		altas.setVisible(false);		
		altas.setResizable(false);

		// ******** DIALOGO COBRAR ********
		//Ensamble dialogo cobrar
		cobrar.setLayout(new GridBagLayout());
		cobrar.setSize(340,450);
		GridBagConstraints gbcCobrar = new GridBagConstraints();
		gbcCobrar.fill = GridBagConstraints.BOTH;
		Insets separaciones2 = new Insets(2,2,2,2);
		gbcCobrar.insets = separaciones2;
		gbcCobrar.gridx = 0;
		gbcCobrar.gridy = 0;
		gbcCobrar.gridwidth = 4;
		gbcCobrar.gridheight = 1;
		cobrar.add(importeEntregado, gbcCobrar);
		gbcCobrar.gridy = 1;
		gbcCobrar.gridwidth = 1;
		cobrar.add(n7cobrar,gbcCobrar);
		gbcCobrar.gridx = 1;
		cobrar.add(n8cobrar,gbcCobrar);
		gbcCobrar.gridx = 2;
		cobrar.add(n9cobrar,gbcCobrar);
		gbcCobrar.gridx = 3;
		gbcCobrar.gridheight = 2;
		cobrar.add(okcobrar,gbcCobrar);
		gbcCobrar.gridx = 0;
		gbcCobrar.gridy = 2;
		gbcCobrar.gridheight = 1;
		cobrar.add(n4cobrar , gbcCobrar);
		gbcCobrar.gridx = 1;
		cobrar.add(n5cobrar,gbcCobrar);
		gbcCobrar.gridx = 2;
		cobrar.add(n6cobrar,gbcCobrar);
		gbcCobrar.gridx = 0;
		gbcCobrar.gridy = 3;
		cobrar.add(n1cobrar,gbcCobrar);
		gbcCobrar.gridx = 1;
		cobrar.add(n2cobrar,gbcCobrar);
		gbcCobrar.gridx = 2;
		cobrar.add(n3cobrar,gbcCobrar);
		gbcCobrar.gridx = 3;
		gbcCobrar.gridheight = 2;
		cobrar.add(esccobrar,gbcCobrar);
		gbcCobrar.gridheight = 1;
		gbcCobrar.gridx = 0;
		gbcCobrar.gridy = 4;
		cobrar.add(n0cobrar,gbcCobrar);
		gbcCobrar.gridx = 1;
		cobrar.add(comacobrar,gbcCobrar);
		gbcCobrar.gridx = 2;
		cobrar.add(delcobrar,gbcCobrar);

		//Listener del Dialogo Cobrar
		cobrar.addWindowListener( new WindowAdapter(){
			public void windowClosing(WindowEvent we){
				cobrar.setVisible(false);
				importe="";
				importeEntregado.setText(importe);
			}
		});
		n0cobrar.addActionListener(this);
		n1cobrar.addActionListener(this);
		n2cobrar.addActionListener(this);
		n3cobrar.addActionListener(this);
		n4cobrar.addActionListener(this);
		n5cobrar.addActionListener(this);
		n6cobrar.addActionListener(this);
		n7cobrar.addActionListener(this);
		n8cobrar.addActionListener(this);
		n9cobrar.addActionListener(this);
		comacobrar.addActionListener(this);
		delcobrar.addActionListener(this);
		esccobrar.addActionListener(this);
		okcobrar.addActionListener(this);

		// Coloreamos botones
		n0cobrar.setBackground(Azul);
		n1cobrar.setBackground(Azul);
		n2cobrar.setBackground(Azul);
		n3cobrar.setBackground(Azul);
		n4cobrar.setBackground(Azul);
		n5cobrar.setBackground(Azul);
		n6cobrar.setBackground(Azul);
		n7cobrar.setBackground(Azul);
		n8cobrar.setBackground(Azul);
		n9cobrar.setBackground(Azul);
		comacobrar.setBackground(Azul);
		delcobrar.setBackground(Azul);
		okcobrar.setBackground(Verde);
		esccobrar.setBackground(Rojo);

		//Damos dimensiones a los Componentes
		
		n0cobrar.setPreferredSize(botonnumero);
		n1cobrar.setPreferredSize(botonnumero);
		n2cobrar.setPreferredSize(botonnumero);
		n3cobrar.setPreferredSize(botonnumero);
		n4cobrar.setPreferredSize(botonnumero);
		n5cobrar.setPreferredSize(botonnumero);
		n6cobrar.setPreferredSize(botonnumero);
		n7cobrar.setPreferredSize(botonnumero);
		n8cobrar.setPreferredSize(botonnumero);
		n9cobrar.setPreferredSize(botonnumero);
		// Evitamos que los botones cojan el Foco
		n0cobrar.setFocusable(false);
		n1cobrar.setFocusable(false);
		n2cobrar.setFocusable(false);
		n3cobrar.setFocusable(false);
		n4cobrar.setFocusable(false);
		n5cobrar.setFocusable(false);
		n6cobrar.setFocusable(false);
		n7cobrar.setFocusable(false);
		n8cobrar.setFocusable(false);
		n9cobrar.setFocusable(false);
		comacobrar.setFocusable(false);
		delcobrar.setFocusable(false);
		okcobrar.setFocusable(false);
		esccobrar.setFocusable(false);
		
		importeEntregado.setEditable(false);
		cobrar.setVisible(false);		
		cobrar.setResizable(false);
		
		// ******** DIALOGO NUEVO TICKET ********
		nuevoTicket.setLayout(new FlowLayout(FlowLayout.CENTER));
		nuevoTicket.setSize(360,320);
		
		nuevoTicket.add(mesa1);
		mesa1.setPreferredSize(botonmediano);
		mesa1.setBackground(Amarillo);
		nuevoTicket.add(mesa2);
		mesa2.setPreferredSize(botonmediano);
		mesa2.setBackground(Amarillo);
		nuevoTicket.add(mesa3);
		mesa3.setPreferredSize(botonmediano);
		mesa3.setBackground(Amarillo);
		nuevoTicket.add(mesa4);
		mesa4.setPreferredSize(botonmediano);
		mesa4.setBackground(Amarillo);
		nuevoTicket.add(mesa5);
		mesa5.setPreferredSize(botonmediano);
		mesa5.setBackground(Amarillo);
		nuevoTicket.add(mesa6);
		mesa6.setPreferredSize(botonmediano);
		mesa6.setBackground(Amarillo);
		nuevoTicket.add(mesa7);
		mesa7.setPreferredSize(botonmediano);
		mesa7.setBackground(Amarillo);
		nuevoTicket.add(mesa8);
		mesa8.setPreferredSize(botonmediano);
		mesa8.setBackground(Amarillo);
		nuevoTicket.add(mesa9);
		mesa9.setPreferredSize(botonmediano);
		mesa9.setBackground(Amarillo);
		nuevoTicket.add(mesa10);
		mesa10.setPreferredSize(botonmediano);
		mesa10.setBackground(Amarillo);
		nuevoTicket.add(barra);
		barra.setPreferredSize(botonmediano);
		barra.setBackground(Amarillo);
		nuevoTicket.add(llevar);
		llevar.setPreferredSize(botonmediano);
		llevar.setBackground(Amarillo);
		
		mesa1.addActionListener(this);
		mesa2.addActionListener(this);
		mesa3.addActionListener(this);
		mesa4.addActionListener(this);
		mesa5.addActionListener(this);
		mesa6.addActionListener(this);
		mesa7.addActionListener(this);
		mesa8.addActionListener(this);
		mesa9.addActionListener(this);
		mesa10.addActionListener(this);
		barra.addActionListener(this);
		llevar.addActionListener(this);
		
		nuevoTicket.addWindowListener(new WindowAdapter(){
			public void windowClosing(WindowEvent we){
				nuevoTicket.setVisible(false);
			}
		});
		nuevoTicket.setVisible(false);
		nuevoTicket.setResizable(true);
	}

	// ******************** MAIN ***********************
	public static void main(String[] args) {

		// Inciamos conexi�n con Base de Datos
		try
		{
			Class.forName("com.mysql.jdbc.Driver");
			conexion = DriverManager.getConnection(dsn, "admin", "a2b3C4");
		}
		catch(Exception e)
		{
			System.out.println("ERROR EN BASE DE DATOS" + e.toString());	
		}
		// Cargamos GUI
		new VersionButtonsDeprecated();


	}

	// ******************** METODOS EVENTOS ACTIONPERFORMED ***********************
	public void actionPerformed(ActionEvent ae) {

		// ABRIR DIALOGO ALTAS
		if (ae.getSource()==botonNuevoArticulo){ 
			altas.setTitle("Art�culo no registrado " + categoriaActiva); 
			altas.setVisible(true);
		}
		// ABRIR DIALOGO COBRAR
		if (ae.getSource()==botonCobrar){ 
			cobrar.setVisible(true);
		}
		
		//ABRIR DIALOGO NUEVO TICKET
		if (ae.getSource()==botonNuevoTicket){
			nuevoTicket.setVisible(true);
		}
		
		// A�ADIR TICKECT NUEVO MESAS (SOLO UN TICKET POR MESA PUEDE ESTAR ACTIVO)
		if (((Button)ae.getSource()).getLabel().matches("Mesa \\d*")){
			Button boton = (Button)ae.getSource();
			boolean existe = false;
			for (Component abiertos : ticketsAbiertos.getComponents()) {
				if (((Button)abiertos).getLabel()==boton.getLabel()){
					existe = true;
				}
			}
			if (!existe){
				listaTicketsAbiertos.add(new Ticket(boton.getLabel(), stmt));
				Ticket ultimoTicket = listaTicketsAbiertos.get(listaTicketsAbiertos.size()-1);
				ticketsAbiertos.add(ultimoTicket);
				ultimoTicket.addActionListener(this);
				ticketsAbiertos.validate();
				nuevoTicket.setVisible(false);
			}
		}
	
		// A�ADIR TICKECTS BARRA
		if (ae.getSource()==barra){  
			contBarra++;
			listaTicketsAbiertos.add(new Ticket("Barra "+contBarra, stmt));
			Ticket ultimoTicket = listaTicketsAbiertos.get(listaTicketsAbiertos.size()-1);
			ticketsAbiertos.add(ultimoTicket);
			ultimoTicket.addActionListener(this);
			ticketsAbiertos.validate();
			nuevoTicket.setVisible(false);
			
		}
		
		// A�ADIR TICKECTS LLEVAR
		if (ae.getSource()==llevar){
			contLlevar++;
			listaTicketsAbiertos.add(new Ticket("Llevar "+contLlevar, stmt));
			Ticket ultimoTicket = listaTicketsAbiertos.get(listaTicketsAbiertos.size()-1);
			ticketsAbiertos.add(ultimoTicket);
			ultimoTicket.addActionListener(this);
			ticketsAbiertos.validate();
			nuevoTicket.setVisible(false);
		}
		
		// A�ADIR DETALLE A TICKET
		if (listaActiva.contains(ae.getSource())){
			if(activo!=null){
				String nombre = ((Button)ae.getSource()).getLabel();
				activo.a�adeDetalle(nombre, stmt);
				muestraTicketActivo();
			}
		}
		// MOVERSE ENTRE LOS DETALLES DE TICKET
		if (ae.getSource()==botonArriba){
			if (indiceDetalleActivo==-1){
				indiceDetalleActivo=ticketActivoCentral.getComponentCount()-1;
				ticketActivoCentral.getComponent(indiceDetalleActivo).setBackground(Papel);
			} else if (indiceDetalleActivo>0){
				ticketActivoCentral.getComponent(indiceDetalleActivo).setBackground(Color.white);
				indiceDetalleActivo--;
				ticketActivoCentral.getComponent(indiceDetalleActivo).setBackground(Papel);
			}
		}
		if (ae.getSource()==botonAbajo){
			if (indiceDetalleActivo==-1){
				indiceDetalleActivo=0;
				ticketActivoCentral.getComponent(indiceDetalleActivo).setBackground(Papel);
			}else if (indiceDetalleActivo<ticketActivoCentral.getComponentCount()-1){
				ticketActivoCentral.getComponent(indiceDetalleActivo).setBackground(Color.white);
				indiceDetalleActivo++;
				ticketActivoCentral.getComponent(indiceDetalleActivo).setBackground(Papel);
			}
		}
		// BORRAR DETALLE TICKET
		if (ae.getSource()==botonBorrar){
			if (indiceDetalleActivo!=-1){
				if(activo.listaDetalle.get(indiceDetalleActivo).cantidadmenos()){
					activo.listaDetalle.remove(indiceDetalleActivo);
					indiceDetalleActivo --;
					if (activo.listaDetalle .isEmpty()){
						listaTicketsAbiertos.remove(activo);
						ticketsAbiertos.remove(activo);
						ticketsAbiertos.validate();
						activo = null;
					}
				}
			}
			muestraTicketActivo();
		}
		
		// SELECCIONAR TICKET , MARCA TICKET ACTIVO Y MUESTRA SUS LINEAS DE DETALLE
		if (listaTicketsAbiertos.contains(ae.getSource())){
			if (activo!=null){
				activo.setBackground(Color.white);
			}
			activo = (Ticket)ae.getSource();
			activo.setBackground(Rojo);
			indiceDetalleActivo = -1;
			muestraTicketActivo();
		}
		
		// CAMBIA LISTA DE PRODUCTOS SEGUN CATEGORIA SELECCIONADA
		if (((Component)ae.getSource()).getParent()==categorias){ 
			categoriaActiva=((Button)ae.getSource()).getLabel();
			rellenaListaActiva(categoriaActiva);
		}
		// **** EVENTOS BOTONES NUMERICOS ****
		if (((Button)ae.getSource()).getLabel().matches("\\d")){
			if (cantidadArticulo.hasFocus()){
				cantidad +=((Button)ae.getSource()).getLabel();
				cantidadArticulo.setText(cantidad);

			} else if (precioArticulo.hasFocus()){
				precio +=((Button)ae.getSource()).getLabel();
				precioArticulo.setText(precio);

			} else if (cobrar.isVisible()){
				importe +=((Button)ae.getSource()).getLabel();
				importeEntregado.setText(importe);
			}
		}
		// **** EVENTOS BOTON "," ****
		if (((Button)ae.getSource()).getLabel()==","){
			if (cantidadArticulo.hasFocus() && cantidad.indexOf('.')<0){
				cantidad += ".";
				cantidadArticulo.setText(cantidad);

			} else if (precioArticulo.hasFocus() && precio.indexOf('.')<0){
				precio += ".";
				precioArticulo.setText(precio);

			} else if (cobrar.isVisible()){
				if (importe.indexOf('.')<0){
					importe += "."; 
					importeEntregado.setText(importe);
				}

			}
		}
		// **** EVENTOS BOTON "del" ****
		if (((Button)ae.getSource()).getLabel()=="del"){
			if (cantidadArticulo.hasFocus() && cantidad!=""){
				cantidad = cantidad.substring(0, cantidad.length()-1);
				cantidadArticulo.setText(cantidad);
				System.out.println("cazado");
			} else if (precioArticulo.hasFocus() && precio!=""){
				precio = precio.substring(0, precio.length()-1);
				precioArticulo.setText(precio);

			} else if (cobrar.isVisible()){
				if (importe!=""){
					importe = importe.substring(0, importe.length()-1); 
					importeEntregado.setText(importe);
				}

			}
		}
		// **** EVENTOS BOTON "ESC" ****
		if (((Button)ae.getSource()).getLabel()=="ESC"){
			if (altas.isVisible()){
				altas.setVisible(false);
				cantidad="";
				cantidadArticulo.setText(cantidad);
				precio="";
				precioArticulo.setText(precio);
			} else if (cobrar.isVisible()){
				cobrar.setVisible(false);
				importe="";
				importeEntregado.setText(importe);
			}
		}
		// **** EVENTO NUEVO ARTICULO ****
		if (ae.getSource()==nuevoaltas){
			String nombreArticulo = descripcionArticulo.getText();
			if (nombreArticulo!="" && precio!=""){
				try {
					stmt.executeUpdate("INSERT restaurante.Articulos (categoriaArticulo,nombreArticulo,precioArticulo)VALUES ('" + categoriaActiva + "','" + nombreArticulo + "'," + 
							Double.parseDouble(precio)+ ")");
					altas.setVisible(false);
					cantidad="";
					cantidadArticulo.setText(cantidad);
					precio="";
					precioArticulo.setText(precio);
					descripcionArticulo.setText("");
					rellenaListaActiva(categoriaActiva);

				} catch (Exception e) {
					System.out.println("Error SQL" + e.toString());
				}
			}
		}
	}

	// *** MOSTRAR ARTICULOS DE CATEGORIA ACTIVA ***
	public void rellenaListaActiva(String nombreCategoria) {

		// Borramos botones de Panel Articulos Menos nuevo
		for (Component  boton: articulos.getComponents()) {
			if (listaActiva .contains(boton)){
				articulos.remove(boton);
			}
		}
		listaActiva.clear();

		try {
			stmt= conexion.createStatement();
			rs = stmt.executeQuery("SELECT nombreArticulo FROM Articulos WHERE categoriaArticulo='"+nombreCategoria+"'");
			while(rs.next()){
				listaActiva.add(new Button(rs.getString("nombreArticulo")));
			}
		} catch (Exception e) {
			System.out.println("Error SQL" + e.toString());
		}

		for (Button boton : listaActiva) {
			boton.setBackground(Azul);
			boton.setPreferredSize(botonmediano);
			boton.addActionListener(this);
			boton.setFocusable(false);
			articulos.add(boton);			
		}
		articulos.validate();
	}
	
	private void muestraTicketActivo() {
		
		// Borramos botones del Panel
		ticketActivoCentral.removeAll();
		
		if (activo!=null){
			// A�adimos botones del ticket activo
			for (DetalleTicket detalle : activo.listaDetalle){
				ticketActivoCentral.add(new Label("",Label.RIGHT));
			}
			numeroTicket.setText("Ticket n� " + activo.idTicket);
			Double totalTicket = (double)activo.totalTicket()/100;
			DecimalFormat df = new DecimalFormat("0.00");
			sumaTicket.setText("Total... " + df.format(totalTicket) + " Euros.");
			// Damos formato a los botones
			int i = 0;
			for (Component detalle: ticketActivoCentral.getComponents()){
				detalle.setBackground(Color.white);
				detalle.setPreferredSize(new Dimension(295,20));
				((Label)detalle).setText(activo.listaDetalle.get(i).toString());
				i++;
			}
		} else {
			numeroTicket.setText("Ticket n� 000000");
			sumaTicket.setText("0,00");
		}
		if (indiceDetalleActivo!=-1){
			ticketActivoCentral.getComponent(indiceDetalleActivo).setBackground(Papel);
		}
		ticketActivoCentral.validate();
		ticketActivoInferior.validate();
	}
}
