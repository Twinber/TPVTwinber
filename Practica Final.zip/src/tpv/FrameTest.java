package tpv;

import java.awt.Button;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class FrameTest extends Frame{
	Boton b = new Boton("HOLA");
	public static ActionListener ae;
	public FrameTest(){
		setSize(400,300);
		setLayout(new FlowLayout(FlowLayout.CENTER));
		add(b);
		
		setVisible(true);
		
	}
	public static void main(String[] args) {
		ae = new ActionListener() {
			
			public void actionPerformed(ActionEvent e) {
				System.out.println("HOLA");
			}
		};
		new FrameTest();
		
	}
}
