package tpv;

import java.awt.Toolkit;

public class FuentesDisponibles {
	public static void main(String[] args) {
		String[] nombreFuentes=Toolkit.getDefaultToolkit().getFontList();
	    for(int i=0; i<nombreFuentes.length; i++){
	        System.out.println(nombreFuentes[i]);
	    }	
	}
	
}
