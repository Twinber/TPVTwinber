package tpv;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class Testeador {
	static Connection conexion=null;
	static String dsn = new String("jdbc:mysql://localhost/restaurante");
	ResultSet rs=null;
	static Statement stmt = null;
	
	public static void main(String[] args) {
		IniciaConexion();
		
		
	}

	private static void IniciaConexion() {
		try
		{
			Class.forName("com.mysql.jdbc.Driver");
			conexion = DriverManager.getConnection(dsn, "admin", "a2b3C4");
			stmt = conexion.createStatement();
		}
		catch(Exception e)
		{
			System.out.println("ERROR EN BASE DE DATOS" + e.toString());	
		}
		Ticket ticketPrueba = new Ticket("Mesa 1", stmt);
		ticketPrueba.a�adeDetalle("CocaCola", stmt);
		ticketPrueba.a�adeDetalle("Cool", stmt);
		ticketPrueba.a�adeDetalle("Cool", stmt);
		ticketPrueba.a�adeDetalle("Ensalada Marisco", stmt);
		ticketPrueba.a�adeDetalle("Ensalada Marisco", stmt);
		ticketPrueba.a�adeDetalle("Ensalada Marisco", stmt);
		System.out.println(ticketPrueba.toString());
	}
}
