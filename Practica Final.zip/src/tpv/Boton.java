package tpv;

import java.awt.Insets;

import javax.swing.JButton;

public class Boton extends JButton{
	private String nombreBoton;
	public Boton(String label){
		setText("<html><p align=\"center\">"+label+"</p></html>");
		setMargin(new Insets(1,1,1,1));
		nombreBoton = label;
	}
	public Boton(){
		setText("");
		setMargin(new Insets(1,1,1,1));
		nombreBoton="";
	}
	
	public String getNombre(){
		return nombreBoton;
	}
	public void setNombre(String nombre){
		nombreBoton=nombre;
		nombre.replaceAll(" ", "&nbsp;");
		setText("<html><p align=\"center\">"+nombre+"</p></html>");
	}
}
